package Negocio;

public class Peixe extends Animal{
	
	public Peixe(String n, int i, double p) {
		super(n, i, p);
	}

	
	
	
}
