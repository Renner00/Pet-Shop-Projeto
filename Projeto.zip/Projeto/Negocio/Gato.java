package Negocio;

public class Gato extends Animal {
	
	public Gato (String n, int i, double p) {
		super(n, i, p);
	}

	
	
	

}
