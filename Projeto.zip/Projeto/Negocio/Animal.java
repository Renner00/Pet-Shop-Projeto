package Negocio;

public abstract class Animal {
	private String nome;
	private int idade;
	private double peso;
	
	public Animal (String n, int i, double p) {
		this.nome = n;
		this.idade = i;
		this.peso = p;
	}
	
	public void realizarBT() {
		System.out.println("O animal " + this.getNome() + "realizou o banho e tosa.");
	}
	public void realizarCV() {
		System.out.println("O animal " + this.getNome() + "recebeu cuidados veterinários.");
	}
	
	public String getNome() {
		return this.nome;
	}
	public int getIdade() {
		return this.idade;
	}
	public double getPeso() {
		return this.peso;
	}
	public void setNome(String n) {
		this.nome = n;
	}
	public void setIdade(int i) {
		this.idade = i;
	}
	public void setPeso(double p) {
		this.peso = p;
	}


}
