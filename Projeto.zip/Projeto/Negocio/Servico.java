package Negocio;

public interface Servico {
	public abstract void realizarServico();
}
