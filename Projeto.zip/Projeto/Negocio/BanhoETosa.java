package Negocio;

public class BanhoETosa implements Servico{

	@Override
	public void realizarServico() {
		System.out.println("Serviço de Banho e Tosa!");
		System.out.println("Realizando serviço...");
		try {
			Thread.sleep(3000);
			System.out.println("Banho e Tosa concluídos");
		} catch (InterruptedException e) {
			System.out.println("Erro ao realizar serviço" + e.getMessage());
		}
	}
	
}
