package Negocio;

public class Item {
	private String nome;
	private double preco;
	
	public Item(String n, double pr) {
		this.nome = n;
		this.preco = pr;
	}
	
	public String getNome() {
		return this.nome;
	}
	public double getPreco() {
		return this.preco;
	}
	public void setNome(String n) {
		this.nome = n;
	}
	public void setPreco(double pr) {
		this.preco = pr;
	}
}
