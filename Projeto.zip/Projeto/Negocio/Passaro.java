package Negocio;

public class Passaro extends Animal{
	
	public Passaro(String n, int i, double p) {
		super(n, i, p);
	}

	

	
}
