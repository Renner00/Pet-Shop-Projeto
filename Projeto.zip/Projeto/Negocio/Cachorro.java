package Negocio;

public class Cachorro extends Animal{
	
	public Cachorro(String n,int i,double p) {
		super(n, i, p);
	}
	
	

}
