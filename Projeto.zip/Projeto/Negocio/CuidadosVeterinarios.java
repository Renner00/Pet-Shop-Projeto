package Negocio;

public class CuidadosVeterinarios implements Servico {

	@Override
	public void realizarServico() {
		System.out.println("Serviço de Cuidados Veterinários!");
		System.out.println("Realizando cuidados...");
		try {
			Thread.sleep(2000);
			System.out.println("Cuidados realizados!");
		} catch (InterruptedException e) {
			System.out.println("Erro ao realizar cuidados: " + e.getMessage());
		}
	}

}
