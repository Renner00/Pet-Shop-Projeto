package Dados;

import Negocio.Item;

import java.util.ArrayList;
import java.util.List;

public class RepositorioItens {
	private List<Item> itens;
	
	public RepositorioItens() {
		this.itens = new ArrayList<>();
		this.itens.add(new Item("Ração para Cães", 20.0));
		this.itens.add(new Item("Ração para Gatos", 15.0));
		this.itens.add(new Item("Ração para Pássaros", 15.0));
		this.itens.add(new Item("Ração para Peixes", 20.0));
		this.itens.add(new Item("Coleira para Cachorro", 30.0));
		this.itens.add(new Item("Coleira para Gato", 25.0));
	}
	
	public void adicionarItem(Item item) {
		this.itens.add(item);
	}
	public void removerItem(Item item) {
		this.itens.add(item);
	}
	public List<Item> listaItens(){
		return this.itens;
	}
	
}
