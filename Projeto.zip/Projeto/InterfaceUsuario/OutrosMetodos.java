package InterfaceUsuario;

import Negocio.Animal;
import Negocio.Servico;
import Negocio.Cachorro;
import Negocio.Gato;
import Negocio.Passaro;
import Negocio.Peixe;
import Negocio.BanhoETosa;
import Negocio.CuidadosVeterinarios;
import Dados.RepositorioItens;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
import Negocio.*;

public class OutrosMetodos {
	private static List<Item> IC = new ArrayList<>();
	private static List<Animal> animais = new ArrayList<>();
	private static Scanner scan = new Scanner(System.in);
	private static RepositorioItens RI = new RepositorioItens();

	private static void adicionarAnimal() {
		System.out.println("Digite o tipo de animal:");
		System.out.println("(Cachorro, gato, pássaro ou peixe)");
		String tipoAnimal = scan.nextLine();
		System.out.println("Digite o nome do animal: ");
		String n = scan.nextLine();
		System.out.println("Digite a idade do animal: ");
		int i = scan.nextInt();
		scan.nextLine();
		System.out.println("Digite o peso do animal: ");
		double p = scan.nextDouble();
		
		Animal animal;
		switch (tipoAnimal.toLowerCase()) {
		case "cachorro":
		    animal = new Cachorro(n, i, p);
		break;
		case "gato":
			animal = new Gato(n, i, p);
			break;
		case "pássaro":
			animal = new Passaro(n, i, p);
			break;
		case "peixe":
			animal = new Peixe(n, i, p);
			break;
		default:
			System.out.println("Tipo de animal inválido!");
			return;
		}
		
		animais.add(animal);
		System.out.println("Animal adicionado com sucesso!");
	}
	
	private static void listarAnimais() {
		if (animais.isEmpty()) {
			System.out.println("Nenhum animal cadastrado");
		} else {
		System.out.println("Lista de Animais: ");
		for (int i= 0; i< animais.size(); i++) {
			System.out.println((i + 1) + " - " + animais.get(i).getClass().getSimpleName()+ ": " + 
		    animais.get(i).getNome() + " - " + animais.get(i).getIdade() + " anos " + " - " + animais.get(i).getPeso() + " kg");
		    }
		}
	}
	
	private static void realiServico(Servico s, Animal a) {
		s.realizarServico();
	}
	private static void removerAnimal() {
		if (animais.isEmpty()) {
			listarAnimais();
			System.out.println("Nenhum animal cadastrado.");
		} else {
			listarAnimais();
			System.out.println("Digite a posição do animal no índice para ser removido: ");
			int i = scan.nextInt();
			scan.nextLine();
			i--;
			
			if (i >= 0 && i < animais.size()) {
				animais.remove(i);
				System.out.println("Animal removido!");
			} else {
				System.out.println("Índice Inválido");
			}
		}
		
	}
	
	private static void comprarItem() {
		System.out.println("Lista dos Itens disponíveis:");
		List<Item> itens = RI.listaItens();
		for (int i=0; i< itens.size();i++) {
			System.out.println((i + 1) + " - " + itens.get(i).getNome() + " - R$ " + itens.get(i).getPreco());
		}
		System.out.println("Digite o número do item que deseja comprar: ");
		System.out.println("Digite 0 para voltar ao menu.");
		int i = scan.nextInt();
		scan.nextLine();
		i--;
		
		if (i == -1) {
			return;
		}
		else {
			List<Item> itenss = RI.listaItens();
			if (i >= 0 && i < itenss.size()) {
				Item itemComprar = itenss.get(i);
				System.out.println("Item " + itemComprar.getNome() + " adicionado no carrinho!");
				adicionarItem(itemComprar);
			} else {
				System.out.println("Item inválido!");
			}
		}
	}
	
	private static void adicionarItem(Item item) {
		IC.add(item);
	}
	private static void listaItens() {
		if (IC.isEmpty()) {
			System.out.println("Nenhum item no carrinho");
		}
		else {
			System.out.println("Carrinho de itens:");
			for (int i=0; i<IC.size();i++) {
				System.out.println((i+1) + " - " + IC.get(i).getNome());
			}
			System.out.println("Preço total dos itens: " + totalItens());
		}
	}
	
	private static double totalItens() {
		double total = 0.0;
		for (Item item : IC) {
			total += item.getPreco();
		}
		return total;
	}
	
	protected static void exibirMenu() {
		int opcao;
		do {
			System.out.println("----------------------------");
			System.out.println("Escolha uma das opções abaixo:");
			System.out.println("1- Adicionar Animal");
			System.out.println("2- Remover Animal");
			System.out.println("3- Listar Animais");
			System.out.println("4- Banho e Tosa");
			System.out.println("5- Cuidados Veterinários");
			System.out.println("6- Comprar Item");
			System.out.println("7- Carrinho de itens");
			System.out.println("8- Sair");
			opcao = scan.nextInt();
			scan.nextLine();
			switch(opcao) {
			case 1:
				adicionarAnimal();
				break;
			case 2:
				removerAnimal();
				break;
			case 3:
				listarAnimais();
				break;
			case 4:
				if (!animais.isEmpty()) {
					System.out.println("Escolha o animal para o banho e tosa:");
					listarAnimais();
					int ea = scan.nextInt();
					scan.nextLine();
					ea--;
					if (ea >= 0 && ea < animais.size()) {
						realiServico(new BanhoETosa(), animais.get(ea));
					}
					else {
						System.out.println("Animal inválido!");
					}
				} else {
					System.out.println("Nenhum animal cadastrado");
				}
				break;
			case 5:
				if (!animais.isEmpty()) {
					System.out.println("Escolha o animal para os cuidados veterinários:");
					listarAnimais();
					int ea = scan.nextInt();
					scan.nextLine();
					ea--;
					if (ea >= 0 && ea < animais.size()) {
						realiServico(new CuidadosVeterinarios(),animais.get(ea));
					} else {
						System.out.println("Animal inválido!");
					}
				} else {
					System.out.println("Nenhum animal cadastrado");
				}
				break;
			case 6:
				comprarItem();
				break;
			case 7:
				listaItens();
				break;
			case 8:
				System.out.println("Saindo...");
				break;
			default:
				System.out.println("Opção inválida. Tente Novamente!");
			}

		}while (opcao != 8);
	}
}
