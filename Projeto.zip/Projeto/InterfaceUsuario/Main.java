package InterfaceUsuario;


public class Main {

	public static void main(String[] args) {
		System.out.println("Bem Vindo ao nosso Pet Shop");
		OutrosMetodos.exibirMenu();
	}
}
